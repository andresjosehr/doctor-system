export default {
    apiURL: "http://144.202.117.98:8080/api",
    appUrl: "http://localhost/work/"
}