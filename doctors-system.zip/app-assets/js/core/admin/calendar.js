import environment from '../../../../environment.js'
import { checkLogin, logout, checkLonginAdministrator } from './../general.js'


$(document).ready(()=>{
    
});